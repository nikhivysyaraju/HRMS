import React, { Component } from 'react'

export default class First extends Component {
  render() {
    return (
      <div>
          <h1>jkll</h1>
      </div>
    )
  }
}
