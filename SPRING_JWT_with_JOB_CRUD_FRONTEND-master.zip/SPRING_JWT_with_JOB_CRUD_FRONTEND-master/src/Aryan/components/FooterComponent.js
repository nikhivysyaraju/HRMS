import React, { Component } from 'react';

class FooterComponent extends Component {
    render() {
        return (
            <div>
                <footer style={{backgroundColor:"#20b2aa"}} className='footer'>
                    <span style={{color:"black"}} className='footerText'>All Rights Reserved 2022 @RajAryan</span>
                </footer>
            </div>
        );
    }
}

export default FooterComponent;