import React from 'react'

export default function LogOut() {
    return (
        <div>
            <h1>Logout page</h1>
        </div>
    )
}
