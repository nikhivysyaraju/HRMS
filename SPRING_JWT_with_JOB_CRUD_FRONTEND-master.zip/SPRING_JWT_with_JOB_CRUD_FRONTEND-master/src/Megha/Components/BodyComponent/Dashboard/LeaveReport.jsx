import React from 'react'

export default function LeaveReport() {
    return (
        <div>
            <h1>Leave report of Employee</h1>
        </div>
    )
}
