import React from 'react'

export default function ViewSalary() {
    return (
        <div>
            <h1> View Employee's Salary</h1>
        </div>
    )
}
